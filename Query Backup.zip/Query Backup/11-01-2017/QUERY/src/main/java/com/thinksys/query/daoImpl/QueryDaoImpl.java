package com.thinksys.query.daoImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.thinksys.query.dao.QueryDao;
import com.thinksys.query.model.Employee;

@Repository
public class QueryDaoImpl implements QueryDao{


	@Autowired
	JdbcTemplate jbdcTemplate;	


	@Override
	public void fetch(String data) {

		System.out.println("anuj"+jbdcTemplate);

		/*List userList = new ArrayList();

		  String sql = "select * from user";

		  userList = jbdcTemplate.query(sql, new UserRowMapper());
		 */
		String sql = "SELECT * FROM firebase_detail";

		List<Employee> customers = new ArrayList<Employee>();
		List<Map<String, Object>> rows =  jbdcTemplate.queryForList(sql);
		System.out.println(rows);
		for (Map row : rows) {
			Employee emp=  new Employee();
			emp.setBrowser_name((String)row.get("browser_name"));
			emp.setToken_id((String)row.get("token_id"));
			customers.add(emp);
			System.out.println(customers);
		}
		
		List<Employee> customer  = jbdcTemplate.query(sql,
				new BeanPropertyRowMapper(Employee.class));
		
		
		System.out.println(customer);

	}

}
