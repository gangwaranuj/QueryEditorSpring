package com.thinksys.query.dao;

public interface QueryDao {

	
	public void fetch(String data);
	
	
	
	
}
