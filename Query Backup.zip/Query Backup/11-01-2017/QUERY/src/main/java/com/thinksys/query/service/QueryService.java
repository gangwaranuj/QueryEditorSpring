package com.thinksys.query.service;

public interface QueryService {

	
	public void fetchData(String query);
	
	
	
}
