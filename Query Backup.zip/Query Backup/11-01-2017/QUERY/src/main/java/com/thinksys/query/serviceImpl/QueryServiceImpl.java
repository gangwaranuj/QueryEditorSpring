package com.thinksys.query.serviceImpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thinksys.query.dao.QueryDao;
import com.thinksys.query.service.QueryService;

@Service
public class QueryServiceImpl implements QueryService{

	private static final Logger logger = LoggerFactory.getLogger(QueryServiceImpl.class);
	
	@Autowired
	QueryDao queryDao;
	
	
	@Override
	public void fetchData(String query) {

		this.queryDao.fetch(query);
		logger.info("Welcome home! The client locale is {}.", "in service");
		
		System.out.println();
		
	}

	
	
	
	
}
