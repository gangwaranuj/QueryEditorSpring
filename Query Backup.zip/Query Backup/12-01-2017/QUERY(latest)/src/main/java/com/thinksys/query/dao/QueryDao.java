package com.thinksys.query.dao;

import java.util.List;

import com.thinksys.query.model.Table;
import com.thinksys.query.util.Response;

public interface QueryDao {

	
	public Response findTables();
	public Response findColumns(String tablename);
	
	
	
	
}
