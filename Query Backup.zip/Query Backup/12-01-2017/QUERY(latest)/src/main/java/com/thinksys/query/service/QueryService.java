package com.thinksys.query.service;

import com.thinksys.query.util.JsonResponse;

public interface QueryService {

	
	public JsonResponse<String> fetchTablesName();
	public JsonResponse<String> fetchTableColumns(String tablename);
	
	
	
	
}
