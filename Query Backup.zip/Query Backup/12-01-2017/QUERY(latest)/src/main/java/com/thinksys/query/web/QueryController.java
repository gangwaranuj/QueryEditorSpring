package com.thinksys.query.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.thinksys.query.service.QueryService;
import com.thinksys.query.util.JsonResponse;


@RestController
public class QueryController {


	@Autowired
	QueryService queryService;


	@CrossOrigin(origins={"*"})
	@RequestMapping(value = "/tablesList", method = RequestMethod.GET)
	public JsonResponse<String> getTableList() {
		JsonResponse<String> list=this.queryService.fetchTablesName();
		return list;
	}

	@CrossOrigin(origins={"*"})
	@RequestMapping(value = "/columnsList", method = RequestMethod.GET)
	public JsonResponse<String> getColoumnList() {
		JsonResponse<String> list=this.queryService.fetchTableColumns("firebase_detail");
		return list;
	}
}
