package com.thinksys.query.serviceImpl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.thinksys.query.dao.QueryDao;
import com.thinksys.query.service.QueryService;
import com.thinksys.query.util.Constants;
import com.thinksys.query.util.JsonResponse;
import com.thinksys.query.util.Response;

@Service
public class QueryServiceImpl implements QueryService{
	private Logger logger = LoggerFactory.getLogger(QueryServiceImpl.class);

	@Autowired
	QueryDao queryDao;


	@SuppressWarnings("unchecked")
	public JsonResponse<String> fetchTablesName() {

		JsonResponse<String> jsonResponse=null;
		try{
			Response response =	this.queryDao.findTableList();
			if(response.isStatus()){
				List<String> list =(List<String>) response.getData();
				jsonResponse=new JsonResponse<String>(Constants.SUCCESS, list, list.size());
			}
		}catch(Exception e){
			this.logger.info("TableList " + e.getMessage());
		}
		return jsonResponse;

	}





}
