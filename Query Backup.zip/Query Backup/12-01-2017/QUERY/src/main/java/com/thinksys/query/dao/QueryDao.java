package com.thinksys.query.dao;

import com.thinksys.query.util.Response;

public interface QueryDao {

	
	public Response findTableList();
	
	
	
	
}
