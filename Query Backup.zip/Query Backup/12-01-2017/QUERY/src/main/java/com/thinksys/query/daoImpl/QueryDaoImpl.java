package com.thinksys.query.daoImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.thinksys.query.dao.QueryDao;
import com.thinksys.query.model.Table;
import com.thinksys.query.util.Constants;
import com.thinksys.query.util.Response;

@Repository
public class QueryDaoImpl implements QueryDao{


	@Autowired
	JdbcTemplate jbdcTemplate;	


	@Override
	public Response findTableList() {

		Response response = new Response();
		
		List<Map<String,Object>> tableList =  jbdcTemplate.queryForList(Constants.SELECT_ALL_TABLE);
		List<String> tables = new ArrayList<String>();
		
		for (Map<String,Object> tableMap : tableList) {
			Table tableBean=  new Table();
			tableBean.setTablename((String)tableMap.get("table_name"));
			tables.add(tableBean.getTablename());
		}
		if(tables.size()>0){
			response.setStatus(true);
			response.setData(tables);
		}else{
			response.setStatus(false);
		}

		/*
		List<Employee> customer  = jbdcTemplate.query(sql,
				new BeanPropertyRowMapper(Employee.class));
		 */
		return response;
	}




}
